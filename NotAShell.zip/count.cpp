#include <bits/stdc++.h>
int main(){
    int count=0;
    while(true){
        std::cout<<count++<<"\n";
    }
}